"""Elementary number theory with reproducible examples."""
from math import gcd, isqrt

def is_prime(n: int) -> bool:
    if n < 2:
        return False
    return all(n % d for d in range(2, isqrt(n) + 1))

def coprime(a: int, b: int) -> bool:
    return gcd(a, b) == 1

def primes_up_to(limit: int) -> list[int]:
    return [n for n in range(2, limit + 1) if is_prime(n)]

if __name__ == '__main__':
    print('Primes up to 100:', primes_up_to(100))
    print('Coprime(35, 64):', coprime(35, 64))
