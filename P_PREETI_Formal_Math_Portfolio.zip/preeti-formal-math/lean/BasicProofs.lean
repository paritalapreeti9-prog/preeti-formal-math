-- Lean 4 educational proofs (core Lean, no Mathlib dependency)
namespace PreetiMath

theorem add_zero_right (n : Nat) : n + 0 = n := by
  simp

theorem add_commutative (a b : Nat) : a + b = b + a := by
  exact Nat.add_comm a b

theorem and_swap (p q : Prop) : p ∧ q → q ∧ p := by
  intro h
  exact ⟨h.2, h.1⟩

theorem implication_chain (p q r : Prop) : (p → q) → (q → r) → p → r := by
  intro hpq hqr hp
  exact hqr (hpq hp)

end PreetiMath
