import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'python'))
from number_theory import is_prime, coprime, primes_up_to

def test_primes():
    assert primes_up_to(10) == [2, 3, 5, 7]

def test_nonprimes():
    assert not is_prime(1) and not is_prime(25)

def test_coprime():
    assert coprime(35, 64) and not coprime(21, 35)
