(* Coq/Rocq educational examples *)
From Coq Require Import Arith.

Theorem add_zero_right : forall n : nat, n + 0 = n.
Proof.
  intro n. apply Nat.add_0_r.
Qed.

Theorem add_commutative : forall a b : nat, a + b = b + a.
Proof.
  intros a b. apply Nat.add_comm.
Qed.

Theorem and_swap : forall P Q : Prop, P /\ Q -> Q /\ P.
Proof.
  intros P Q H. destruct H as [HP HQ]. split; assumption.
Qed.
